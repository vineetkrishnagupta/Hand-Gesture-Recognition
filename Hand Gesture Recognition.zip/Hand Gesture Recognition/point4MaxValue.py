'''
    if point 4 value is maxmum(y axis) in full list than this function return True, else False.
'''
def max_value_for_point_4(tempList):
    appendList = []
    
    for i in range(len(tempList)):
        appendList.append(tempList[i][1])
    
    if max(appendList) == appendList[4]:
        return True
    
    else:
        False


# this function written by vineet krishna gupta...